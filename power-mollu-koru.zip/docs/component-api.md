# 组件 API 参考

本文档详细说明 `@mollu/koru/topology` 各组件的 Props、Emits、Slots 和实例方法，以及导出的工具函数、composable、插件。

---

## 导出清单

### 组件（17 个）

```
KoruGraphEditor       编辑器主组件（编辑模式）
KoruPreview           预览组件（只读模式）
KoruToolbar           顶部工具栏
KoruStencil           左侧元件拖拽面板
KoruPropertyPanel     右侧属性面板
KoruMinimap           右下角小地图
KoruContextMenu       右键菜单
KoruMultiStateEditorModal  多状态编辑器弹窗
KoruGallery           图库面板
KoruTemplate          模板面板
KoruCanvasPropertyPanel 画布属性面板
KoruNodeRenderer      节点渲染器（内部）
KoruEdgeRenderer      连线渲染器（内部）
KoruLogoName          Logo+名称组件（内部）
KoruModal             通用弹窗（内部）
```

### 类型（40+ 个）

```
KoruGraphData / KoruNodeData / KoruEdgeData / KoruPortData
KoruStencilGroup / KoruStencilNodeItem / CustomShapeItem
KoruCanvasConfig / KoruCanvasGrid / KoruCanvasBackground
KoruGraphEditorMode / KoruGraphEditorOptions / KoruGraphEditorInstance
BindingRegistryItem / BindingRegistryEntry / FlatBindingData
GroupedBindingDataItem / ContextMenuStateData
MultiStateConfig / BindingConfig / DeviceConfig / ComponentConfig
... 等
```

### 工具函数（12 个）

```
registerBasicShapes / registerSvgNode / registerSvgNodes
createDefaultNode / createDefaultCircleNode / createDefaultTextNode
createDefaultButtonNode / createDefaultEdge / createSvgPreviewNode
dbGet / dbSet / dbRemove / uid
```

### Composables（10 个）

```
useKoruGraphEditor / useZoom / useNodeDrag / useSelection
useClipboard / useUndoRedo / useContextMenu
useCanvasPersistence / useBindingRegistry / useCanvasStore
```

### 配置函数（8 个）

```
setMultiStateConfig / resetMultiStateConfig
setBindingConfig / resetBindingConfig
setDeviceConfig / resetDeviceConfig
setComponentConfig / resetComponentConfig
```

### 插件

```
KoruTopologyPlugin    主插件（组件注册 + 基础形状）
plugins/flow          流程编排插件（可选）
plugins/whiteboard    白板标注插件（可选）
```

---

## KoruGraphEditor（编辑器主组件）

编辑模式下的核心组件，集成了 Stencil、工具栏、画布、属性面板、小地图等所有子组件。

### Props

| Prop                     | 类型                                         | 默认值                     | 说明                                                    |
| ------------------------ | -------------------------------------------- | -------------------------- | ------------------------------------------------------- |
| `graph`                  | `KoruGraphData`                              | `{ nodes: [], edges: [] }` | 画布数据（支持 `v-model:graph`）                        |
| `mode`                   | `'edit' \| 'preview'`                        | `'edit'`                   | 画布模式                                                |
| `options`                | `Partial<KoruGraphEditorOptions>`            | `{}`                       | 扩展配置（网格、缩放、权限等）                          |
| `persistenceKey`         | `string`                                     | `'koru-diagram-data'`      | 持久化存储 key，空字符串禁用持久化                      |
| `persistenceConfirm`     | `(savedData) => Promise<boolean> \| boolean` | —                          | 恢复数据前的确认回调                                    |
| `persistenceAdapter`     | `PersistenceStorageAdapter`                  | IndexedDB                  | 自定义存储适配器                                        |
| `stencilGroups`          | `KoruStencilGroup[]`                         | 内置默认 5 个分组          | Stencil 分组数据（自动与默认合并，见 global-config.md） |
| `stencilWidth`           | `number`                                     | `210`                      | Stencil 面板宽度（优先于全局配置）                      |
| `customShapes`           | `CustomShapeItem[]`                          | `[]`                       | SVG 自定义形状列表                                      |
| `toolbarLogo`            | `string`                                     | `''`                       | 工具栏 Logo URL                                         |
| `toolbarName`            | `string`                                     | `''`                       | 工具栏名称                                              |
| `fullscreenTarget`       | `string`                                     | `''`                       | 全屏模式 CSS 选择器                                     |
| `showToolbar`            | `boolean`                                    | `true`                     | 是否显示工具栏                                          |
| `showStencil`            | `boolean`                                    | `true`                     | 是否显示 Stencil 面板                                   |
| `showPropertyPanel`      | `boolean`                                    | `true`                     | 是否显示属性面板                                        |
| `showMinimap`            | `boolean`                                    | `false`                    | 是否显示小地图                                          |
| `multiStatePointOptions` | `{value, label}[]`                           | —                          | ⚠️ 已废弃，请使用 `setMultiStateConfig()`               |

### Emits

| 事件           | Payload                            | 说明                         |
| -------------- | ---------------------------------- | ---------------------------- |
| `update:graph` | `KoruGraphData`                    | 画布数据变更（v-model 同步） |
| `update:mode`  | `'edit' \| 'preview'`              | 模式变更                     |
| `save`         | `{ diagramData, bindingRegistry }` | 用户点击保存按钮             |
| `preview`      | `{ diagramData, bindingRegistry }` | 用户点击预览按钮             |
| `rendered`     | —                                  | 画布渲染完成                 |
| `destroyed`    | —                                  | 画布销毁                     |

### Slots

| 插槽             | 默认内容              | 说明                |
| ---------------- | --------------------- | ------------------- |
| `toolbar`        | `<KoruToolbar>`       | 自定义工具栏        |
| `stencil`        | `<KoruStencil>`       | 自定义 Stencil 面板 |
| `property-panel` | `<KoruPropertyPanel>` | 自定义属性面板      |
| `minimap`        | `<KoruMinimap>`       | 自定义小地图        |
| `context-menu`   | `<KoruContextMenu>`   | 自定义右键菜单      |

### 实例方法（通过 ref 调用）

```ts
const koruRef = ref<InstanceType<typeof KoruGraphEditor>>()
```

#### 视口控制

| 方法                     | 说明           |
| ------------------------ | -------------- |
| `zoomIn()`               | 放大一级       |
| `zoomOut()`              | 缩小一级       |
| `resetView()`            | 重置视图       |
| `fitView()`              | 适应画布内容   |
| `setZoom(scale: number)` | 设置指定缩放值 |

#### 图元操作

| 方法                                  | 说明                   |
| ------------------------------------- | ---------------------- |
| `addNode(node)`                       | 添加节点，返回节点 ID  |
| `removeNode(nodeId)`                  | 删除节点               |
| `updateNode(nodeId, data)`            | 更新节点属性           |
| `addEdge(edge)`                       | 添加连线，返回连线 ID  |
| `removeEdge(edgeId)`                  | 删除连线               |
| `updateEdge(edgeId, data)`            | 更新连线属性           |
| `getCell(cellId)`                     | 获取 cell 实例         |
| `updateCellProp(cellId, key, value)`  | 更新 cell 单个属性     |
| `readCellProps(cellId)`               | 读取 cell 全部属性     |
| `updateSelectedCellsProp(key, value)` | 批量更新选中 cell 属性 |

#### 选区操作

| 方法                 | 说明                    |
| -------------------- | ----------------------- |
| `selectNode(nodeId)` | 选中指定节点            |
| `selectAll()`        | 全选                    |
| `clearSelection()`   | 清除选区                |
| `selection` (getter) | 当前选中的 cell ID 列表 |

#### 撤销/重做

| 方法                    | 说明            |
| ----------------------- | --------------- |
| `undo()`                | 撤销一步        |
| `redo()`                | 重做一步        |
| `canUndo` (getter)      | 是否可撤销      |
| `canRedo` (getter)      | 是否可重做      |
| `removeSelectedCells()` | 删除选中的 cell |

#### 数据操作

| 方法                   | 说明                             |
| ---------------------- | -------------------------------- |
| `getGraphData()`       | 获取当前 `KoruGraphData`         |
| `setGraphData(data)`   | 设置画布数据                     |
| `exportJSON()`         | 导出 JSON 字符串                 |
| `getGraph()`           | 获取底层 X6 Graph 实例           |
| `getBindingRegistry()` | 获取绑定注册表（供后端 WS 订阅） |

#### 模式管理

| 方法              | 说明         |
| ----------------- | ------------ |
| `getMode()`       | 获取当前模式 |
| `setMode(mode)`   | 切换模式     |
| `isEditMode()`    | 是否编辑模式 |
| `isPreviewMode()` | 是否预览模式 |

#### 事件订阅

| 方法                  | 说明         |
| --------------------- | ------------ |
| `on(event, handler)`  | 订阅画布事件 |
| `off(event, handler)` | 取消订阅     |

---

## KoruPreview（预览模式组件）

只读预览组件，支持实时数据绑定、事件触发和触发器执行。

### Props

| Prop              | 类型                                                   | 默认值                     | 说明                                   |
| ----------------- | ------------------------------------------------------ | -------------------------- | -------------------------------------- |
| `graph`           | `{ nodes?, edges?, cells? }`                           | `{ nodes: [], edges: [] }` | 画布数据（支持 `v-model:graph`）       |
| `autoFit`         | `boolean`                                              | `false`                    | 是否自动缩放适配画布                   |
| `showTestTools`   | `boolean`                                              | `false`                    | 是否显示绑定测试工具栏                 |
| `customShapes`    | `CustomShapeItem[]`                                    | `[]`                       | SVG 自定义形状列表                     |
| `outerRequestApi` | `(cfg: OuterRequestRuntimeConfig) => Promise<boolean>` | —                          | 触发器前置请求 API，返回 true 表示成功 |

> **注意**：`fetchData` 和 `pollInterval` 不在 KoruPreview 的直接 props 中，需要通过 `setBindingConfig()` 全局配置。

### Emits

| 事件               | Payload                                    | 说明                                |
| ------------------ | ------------------------------------------ | ----------------------------------- |
| `update:graph`     | `any`                                      | 画布数据变更                        |
| `ready`            | —                                          | 预览组件初始化完成                  |
| `destroyed`        | —                                          | 预览组件销毁                        |
| `cell-event`       | `CellEventPayload`                         | 图元事件（click/dblclick/hover 等） |
| `data-updated`     | `Record<string, number \| string \| null>` | 实时数据更新                        |
| `action-triggered` | `ActionTriggeredPayload`                   | 触发器动作执行                      |

### CellEventPayload

```ts
interface CellEventPayload {
  eventType: string // click / dblclick / mouseenter / ...
  cellId: string
  shape: string
  data: Record<string, any> // cell.getData()
  rawEvent?: any // 原始 X6 事件
}
```

### ActionTriggeredPayload

```ts
interface ActionTriggeredPayload {
  cellId: string
  triggerId: string
  actionType: string
  actionValue: Record<string, any>
  tagValue: number | string | null
  matched: boolean
  binding?: any
  triggerConfig?: any
  cellData?: Record<string, any>
  shape?: string
}
```

### 实例方法

| 方法         | 说明                                             |
| ------------ | ------------------------------------------------ |
| `refresh()`  | 手动触发一次数据刷新（拉取实时数据、重跑触发器） |
| `getGraph()` | 获取底层 X6 Graph 实例                           |

---

## KoruToolbar（工具栏）

顶部工具栏，提供保存、预览、撤销/重做、缩放、全屏等按钮。

### Props

| Prop                 | 类型                              | 默认值 | 说明                          |
| -------------------- | --------------------------------- | ------ | ----------------------------- |
| `logo`               | `string`                          | `''`   | 工具栏 Logo（优先于全局配置） |
| `name`               | `string`                          | `''`   | 工具栏名称（优先于全局配置）  |
| `fullscreenTarget`   | `string \| string[]`              | —      | 全屏容器 CSS 选择器           |
| `onFullscreenChange` | `(isFullscreen: boolean) => void` | —      | 全屏状态变更回调              |

> 以上 props 未传入时，自动回退到 `setComponentConfig()` 的全局配置。

### Emits

| 事件             | Payload                            | 说明       |
| ---------------- | ---------------------------------- | ---------- |
| `save`           | `{ diagramData, bindingRegistry }` | 点击保存   |
| `preview`        | `{ diagramData, bindingRegistry }` | 点击预览   |
| `saveAsTemplate` | `(name: string, data: any)`        | 保存为模板 |

---

## KoruStencil（元件面板）

左侧元件拖拽面板。

### Props

| Prop           | 类型                 | 默认值   | 说明                                              |
| -------------- | -------------------- | -------- | ------------------------------------------------- |
| `groups`       | `KoruStencilGroup[]` | 全局配置 | 分组数据（优先于全局）                            |
| `width`        | `number`             | `210`    | 面板宽度（优先于全局）                            |
| `customShapes` | `CustomShapeItem[]`  | `[]`     | SVG 自定义形状列表（用于 svg-node-\* 的落点尺寸） |

> 如果以上 props 未传入，自动回退到 `setComponentConfig()` 的全局配置。

---

## KoruPropertyPanel（属性面板）

右侧属性编辑面板，支持基础属性、动效、事件、绑定四个 tab。

### Props

| Prop      | 类型      | 默认值 | 说明                               |
| --------- | --------- | ------ | ---------------------------------- |
| `visible` | `boolean` | `true` | 是否可见（支持 `v-model:visible`） |

### Emits

| 事件               | Payload   | 说明                 |
| ------------------ | --------- | -------------------- |
| `update:visible`   | `boolean` | 可见性变更           |
| `edit-multi-state` | —         | 点击"组合为状态"按钮 |

---

## KoruMinimap（小地图）

右下角小地图，显示画布缩略图和视口位置。

### Props

无必须 props。

---

## KoruContextMenu（右键菜单）

右键菜单，提供组合、取消组合、复制、删除等操作。

### Props

| Prop    | 类型                   | 默认值 | 说明                          |
| ------- | ---------------------- | ------ | ----------------------------- |
| `state` | `ContextMenuStateData` | —      | 菜单状态数据（必须为 Object） |

### Emits

| 事件     | Payload  | 说明               |
| -------- | -------- | ------------------ |
| `action` | `string` | 菜单项 action 名称 |
| `close`  | —        | 菜单关闭           |

---

## KoruMultiStateEditorModal（多状态编辑器弹窗）

编辑模式下「组合为状态」功能的弹窗组件，支持将多个节点组合为一个状态元件，配置不同状态下的属性映射。

### 使用方式

通常由 `KoruContextMenu` 自动弹出（右键 → 组合为状态），也可手动调用：

```vue
<koru-multi-state-editor-modal
  v-model:visible="showModal"
  :nodes="selectedNodes"
  @confirm="handleConfirm"
  @cancel="showModal = false"
/>
```

### Props

| Prop      | 类型      | 默认值  | 说明                                 |
| --------- | --------- | ------- | ------------------------------------ |
| `visible` | `boolean` | `false` | 弹窗可见性（支持 `v-model:visible`） |
| `nodes`   | `Node[]`  | `[]`    | 待组合的节点列表（X6 Node 实例）     |

### Emits

| 事件      | Payload | 说明                   |
| --------- | ------- | ---------------------- |
| `confirm` | `any`   | 确认组合（含状态配置） |
| `cancel`  | —       | 取消操作               |

### 配置来源

弹窗中的下拉选项由 `setMultiStateConfig()` 全局配置：

- `pointOptions` → 状态点下拉
- `deviceOptions` → 设备下拉
- `statePresets` → 状态名称快捷预设

> **详细说明**：参见 [global-config.md](./global-config.md#setmultistateconfig多状态配置)

---

## KoruGallery（图库面板）

Stencil 中的图片图库面板，用于管理和选择 `custom-image` 类型的节点。

### Props

| Prop          | 类型                    | 默认值 | 说明                 |
| ------------- | ----------------------- | ------ | -------------------- |
| `resources`   | `GalleryResourceItem[]` | `[]`   | 图库资源列表         |
| `allowUpload` | `boolean`               | `true` | 是否允许上传本地图片 |
| `allowDelete` | `boolean`               | `true` | 是否允许删除已有图片 |

### GalleryResourceItem 类型

```ts
interface GalleryResourceItem {
  id: string
  name: string
  url: string
  thumbnail?: string
  width?: number
  height?: number
}
```

---

## KoruTemplate（模板面板）

Stencil 中的模板面板，用于管理和复用画布模板。

### Props

| Prop        | 类型             | 默认值 | 说明               |
| ----------- | ---------------- | ------ | ------------------ |
| `templates` | `TemplateItem[]` | `[]`   | 模板列表           |
| `allowSave` | `boolean`        | `true` | 是否允许保存为模板 |

### TemplateItem 类型

```ts
interface TemplateItem {
  id: string
  name: string
  thumbnail?: string
  data: any // 画布序列化数据
  createdAt?: string
  updatedAt?: string
}
```

---

## KoruCanvasPropertyPanel（画布属性面板）

独立的画布属性配置面板，用于编辑网格、背景、缩放等画布级配置。

### Props

| Prop      | 类型      | 默认值 | 说明                               |
| --------- | --------- | ------ | ---------------------------------- |
| `visible` | `boolean` | `true` | 是否可见（支持 `v-model:visible`） |

---

## 内部子组件

以下组件通常由其他组件内部使用，不直接面向消费方，但在高级场景下可以独立使用：

| 组件               | 说明                                          |
| ------------------ | --------------------------------------------- |
| `KoruNodeRenderer` | 节点渲染器（`KoruGraphEditor` 内部使用）      |
| `KoruEdgeRenderer` | 连线渲染器（`KoruGraphEditor` 内部使用）      |
| `KoruLogoName`     | Logo + 名称展示组件（`KoruToolbar` 内部使用） |
| `KoruModal`        | 通用弹窗组件（内部复用）                      |

---

## 工具函数 & Composables

除 UI 组件外，库还导出以下工具函数和 composable：

### 存储工具

```ts
import { dbGet, dbSet, dbRemove } from '@mollu/koru/topology'

// 从 IndexedDB 读取数据
const data = await dbGet('my-key')

// 写入 IndexedDB
await dbSet('my-key', JSON.stringify({ nodes: [], edges: [] }))

// 删除 IndexedDB 条目
await dbRemove('my-key')
```

### 绑定注册表工具

```ts
import {
  useBindingRegistry,
  collectBindingRegistry,
  extractBindingKeys,
  flattenBindingData,
  buildFetchData,
} from '@mollu/koru/topology'
import type { BindingRegistryItem, GroupedBindingDataItem } from '@mollu/koru/topology'

// Composable：获取绑定注册表
const { getBindingRegistry } = useBindingRegistry(() => graphRef.value)
const registry = getBindingRegistry()

// 从 Graph 实例采集绑定注册表
const registry2: BindingRegistryItem[] = collectBindingRegistry(graph)

// 提取 "cellId:device:dataPoint" 格式的订阅 Keys
const keys: string[] = extractBindingKeys(registry)

// 将分组格式数据展平为扁平格式
const flat: Record<string, any> = flattenBindingData(groupedData)

// 构建 fetchData 函数（自动对接绑定注册表）
const fetchData = buildFetchData(registry, dataSource)
const flatData = await fetchData()

// 也支持分组格式数据源
const fetchData2 = buildFetchData(registry, groupedDataSource, { inputFormat: 'grouped' })
```

> **详细说明**：参见 [binding-registry.md](./binding-registry.md)

### Canvas Store Composable

```ts
import { useCanvasStore } from '@mollu/koru/topology'

// 获取全局 Canvas Store（reactive 对象）
const store = useCanvasStore()

// 常用属性
store.componentConfig.stencilGroups // Stencil 分组
store.bindingConfig.values // 绑定值缓存
store.deviceConfig.deviceOptions // 设备选项
store.x6GraphRef.value // X6 Graph 实例引用
store.propActiveTab.value // 属性面板 active tab（可用于触发刷新）

// 触发画布绑定刷新
store.propActiveTab.value = Date.now() + ''
```

---

## 插件系统

### 内置插件

| 插件                | 路径                             | 说明                   |
| ------------------- | -------------------------------- | ---------------------- |
| Flow 流程插件       | `@mollu/koru/plugins/flow`       | 为画布添加流程编排能力 |
| Whiteboard 白板插件 | `@mollu/koru/plugins/whiteboard` | 为画布添加白板标注能力 |

### 使用方式

```ts
// main.ts
import { createApp } from 'vue'
import { KoruTopologyPlugin } from '@mollu/koru/topology'
import flowPlugin from '@mollu/koru/plugins/flow'
import whiteboardPlugin from '@mollu/koru/plugins/whiteboard'
import App from './App.vue'

const app = createApp(App)
app.use(KoruTopologyPlugin)
app.use(flowPlugin) // 可选：启用流程编排
app.use(whiteboardPlugin) // 可选：启用白板标注
app.mount('#app')
```

---

## 类型速查

### KoruGraphEditorOptions

```ts
interface KoruGraphEditorOptions {
  mode: 'edit' | 'preview'
  grid: boolean
  gridSize?: number
  zoom: { min: number; max: number }
  panning: boolean
  mouseWheel: boolean
  allowDragNode: boolean
  allowCreateEdge: boolean
  allowDelete: boolean
  allowSelect: boolean
}
```

### KoruStencilGroup

```ts
interface KoruStencilGroup {
  name: string // 分组标识
  label: string // 显示名称
  items: KoruStencilNodeItem[] // 节点项列表
  graphHeight?: number // 分组容器高度
  layoutOptions?: {
    // 布局选项
    columns: number
    columnWidth: number
    rowHeight: number
    dx?: number
  }
  collapsed?: boolean // 是否折叠
}
```

### KoruStencilNodeItem

```ts
interface KoruStencilNodeItem {
  shape: string // 形状标识
  label: string // 显示名称
  width?: number // 缩略图宽度
  height?: number // 缩略图高度
  dropWidth?: number // 拖拽落点宽度
  dropHeight?: number // 拖拽落点高度
  attrs?: Record<string, any> // 自定义属性
  data?: Record<string, any> // 自定义数据
}
```

### CustomShapeItem

```ts
interface CustomShapeItem {
  label: string // 显示名称
  svg: string // SVG 原始字符串
  shapeName?: string // 注册后的 shape 名称（注册后自动填充）
}
```
