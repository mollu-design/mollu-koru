# Mollu-Koru 使用文档

Mollu-Koru 是基于 Vue 3 + @antv/x6 的可视化拓扑图组件库，提供编辑器、预览器、绑定系统、多状态等完整能力。

---

## 文档目录

| 文档                                         | 说明                                                                                               |
| -------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| [quick-start.md](./quick-start.md)           | **快速上手** — 安装、两种注册方式、最小可运行示例、构建产物                                        |
| [component-api.md](./component-api.md)       | **组件 API 参考** — 所有组件的 Props/Emits/Slots/实例方法 + 工具函数 + Composables + 插件          |
| [global-config.md](./global-config.md)       | **全局配置指南** — setMultiStateConfig、setBindingConfig、setDeviceConfig、setComponentConfig 详解 |
| [svg-custom-nodes.md](./svg-custom-nodes.md) | **SVG 自定义节点** — 将 SVG 文件注册为可拖拽节点的完整流程                                         |
| [persistence.md](./persistence.md)           | **持久化与存储** — IndexedDB 自动保存、自定义存储适配器、手动数据操作                              |
| [binding-registry.md](./binding-registry.md) | **绑定注册表** — 前端绑定配置与后端实时数据推送的桥梁                                              |

---

## 推荐阅读路径

```
1. quick-start.md        → 快速跑起来
2. global-config.md      → 配置业务参数
3. component-api.md      → 深入组件 API
4. svg-custom-nodes.md   → 添加自定义图形
5. binding-registry.md   → 对接实时数据系统
6. persistence.md        → 数据保存与恢复
```

---

## 核心架构

```
@mollu/koru
├── 根入口 (index)        → 核心内核、几何工具、渲染抽象
│
├── @mollu/koru/topology  → 拓扑画布主模块
│   ├── KoruGraphEditor  → 编辑器主组件（编辑模式）
│   ├── KoruPreview      → 预览组件（只读模式）
│   ├── KoruToolbar      → 工具栏
│   ├── KoruStencil      → 元件拖拽面板
│   ├── KoruPropertyPanel → 属性面板
│   ├── KoruMinimap      → 小地图
│   ├── KoruContextMenu  → 右键菜单
│   └── ...              → 更多面板、弹窗、工具
│
└── @mollu/koru/plugins/flow → 流程图插件
```

## 技术栈

- **框架**：Vue 3.4+ / TypeScript
- **底层引擎**：@antv/x6 v3
- **UI 组件**：@arco-design/web-vue
- **构建**：Vite Library Mode (ESM + CJS + DTS)

## License

MIT
