# 自定义 SVG 节点注册指南

Koru 支持将任意 SVG 文件注册为可拖拽、可缩放的自定义节点，适用于电气符号、流程图图标、品牌图标等场景。

---

## 内置基础形状

Koru 预置了以下基础形状，开箱即用，无需注册：

| shape 名称 | 说明 | 默认尺寸 |
|------------|------|---------|
| `custom-rect` | 矩形 | 66×36 |
| `custom-polygon` | 多边形 | 66×36 |
| `custom-circle` | 圆形 | 45×45 |
| `custom-image` | 图片节点 | 52×52 |
| `custom-split` | 左右分栏 | 160×40 |
| `custom-text` | 文本节点 | 100×30 |
| `custom-button` | 按钮节点 | 80×32 |
| `shape-line` | 线条节点 | 55×2 |

这些形状通过 `registerBasicShapes()` 注册，通常由 KoruGraphEditor 内部自动调用。

### 创建基础节点

```ts
import { createDefaultNode, createDefaultCircleNode, createDefaultEdge, uid } from '@mollu/koru/topology'

// 创建矩形节点
const node = createDefaultNode({
  x: 100,
  y: 200,
  label: '开始',
})

// 创建圆形节点
const circle = createDefaultCircleNode({
  x: 300,
  y: 150,
  label: '审批',
})

// 创建连线
const edge = createDefaultEdge({
  source: node.id,
  target: circle.id,
  label: '通过',
})
```

---

## 注册自定义 SVG 节点

### 适用场景

当内置形状无法满足需求时（如电力系统的电气符号、行业特定图标等），可以将 SVG 文件注册为自定义节点。

### 核心流程

```
SVG 文件 → CustomShapeItem[] → registerSvgNodes() → X6 Graph.registerNode()
                                    ↓
                              shapeName = "svg-node-{index}"
                                    ↓
                              挂载 defs → 注入 Stencil 预览
```

### 步骤一：准备 SVG 文件

SVG 文件应满足以下条件：
- 使用标准 SVG 格式（`.svg` 扩展名）
- 建议设置 `viewBox` 属性
- 可包含 `<defs>`（如渐变、图案、滤镜）
- 支持文本、路径、矩形、圆形等常用元素

### 步骤二：加载 SVG 文件

使用 Vite 的 `import.meta.glob` 批量加载 SVG：

```ts
// 方式 A：使用 import.meta.glob（Vite 推荐方式）
const svgModules = import.meta.glob('@/assets/svg/*.svg', {
  query: '?raw',     // 获取原始 SVG 字符串
  import: 'default',  // 作为 default 导出
  eager: true,        // 立即加载
}) as Record<string, string>
```

或者通过静态 import 加载单个 SVG：

```ts
import transformerSvg from '@/assets/svg/变压器.svg?raw'
import breakerSvg from '@/assets/svg/断路器.svg?raw'
```

### 步骤三：构建 CustomShapeItem 列表

```ts
import type { CustomShapeItem } from '@mollu/koru/topology'

// 批量方式
const svgMap: Record<string, string> = {}
Object.entries(svgModules).forEach(([path, content]) => {
  const match = path.match(/\/([^/]+)\.svg$/)
  if (match) {
    svgMap[match[1]] = content as string
  }
})

const customShapes: CustomShapeItem[] = Object.entries(svgMap).map(([fileName, svg]) => ({
  label: fileName,   // 显示名称（如"变压器"、"断路器"）
  svg: svg,          // SVG 原始字符串
}))

// 单个方式
const customShapes: CustomShapeItem[] = [
  { label: '变压器', svg: transformerSvg },
  { label: '断路器', svg: breakerSvg },
]
```

### 步骤四：注册到 X6 Graph

`registerSvgNodes()` 需要传入 `Graph` 实例，因此必须在画布初始化完成后调用：

```ts
import { registerSvgNodes, useCanvasStore } from '@mollu/koru/topology'
import type { Graph } from '@antv/x6'

onMounted(() => {
  // 等待 X6 Graph 就绪
  const tryRegister = setInterval(() => {
    const graph: Graph | null = useCanvasStore().x6GraphRef.value
    if (graph) {
      // 批量注册
      registerSvgNodes(customShapes, graph)
      
      // 更新全局配置（Stencil 通过此数据查找落点尺寸）
      setComponentConfig({ customShapes })
      
      clearInterval(tryRegister)
    }
  }, 50)
})
```

注册完成后，每个 SVG 节点会自动获得：
- shape 名称：`svg-node-0`、`svg-node-1`、`svg-node-2`、...
- 四方向连接桩（top/right/bottom/left）
- 自适应的 viewBox 尺寸
- 与 SVG 原始尺寸等比缩放的 hitarea

### 步骤五：加载到 Stencil 面板

注册完成后，使用 `createSvgPreviewNode()` 创建预览节点并加载到 Stencil 分组：

```ts
import { createSvgPreviewNode, useCanvasStore } from '@mollu/koru/topology'

const store = useCanvasStore()
const graph = store.x6GraphRef.value!

// 为每个 SVG 创建 Stencil 预览节点
const svgPreviewNodes = customShapes.map((item) => createSvgPreviewNode(graph, item))

// 加载到指定分组（如"电气符号"分组）
store.loadGroupNodesRef.value?.('electrical', svgPreviewNodes)
```

### 完整示例

```vue
<script setup lang="ts">
import { ref, onMounted } from 'vue'
import {
  setComponentConfig,
  registerSvgNodes,
  createSvgPreviewNode,
  useCanvasStore,
} from '@mollu/koru/topology'
import type { CustomShapeItem, KoruStencilGroup } from '@mollu/koru/topology'

// 1. 配置 Stencil 分组
const stencilGroups: KoruStencilGroup[] = [
  {
    name: 'basic',
    label: '基础图形',
    layoutOptions: { columns: 3, columnWidth: 60, rowHeight: 50 },
    items: [
      { shape: 'custom-rect', label: '长方形', width: 46, height: 30 },
      { shape: 'custom-circle', label: '圆形', width: 40, height: 40 },
    ],
  },
  {
    name: 'electrical',
    label: '电气符号',
    graphHeight: 335,
    layoutOptions: { columns: 4, columnWidth: 45, rowHeight: 45 },
    items: [], // SVG 节点动态加载
  },
]

setComponentConfig({
  stencilGroups,
  customShapes: [],
})

// 2. 加载 SVG 文件
const svgModules = import.meta.glob('@/assets/svg/*.svg', {
  query: '?raw',
  import: 'default',
  eager: true,
}) as Record<string, string>

const svgMap: Record<string, string> = {}
Object.entries(svgModules).forEach(([path, content]) => {
  const match = path.match(/\/([^/]+)\.svg$/)
  if (match) svgMap[match[1]] = content as string
})

const customShapes = ref<CustomShapeItem[]>(
  Object.entries(svgMap).map(([fileName, svg]) => ({
    label: fileName,
    svg,
  })),
)

// 3. 等待 Graph 就绪后注册
onMounted(() => {
  const tryRegister = setInterval(() => {
    const graph = useCanvasStore().x6GraphRef.value
    if (graph) {
      // 注册 SVG 节点
      registerSvgNodes(customShapes.value, graph)

      // 同步到全局配置（供 Stencil 查找落点尺寸）
      setComponentConfig({ customShapes: customShapes.value })

      // 加载预览节点到 Stencil
      const svgNodes = customShapes.value.map((item) =>
        createSvgPreviewNode(graph, item),
      )
      useCanvasStore().loadGroupNodesRef.value?.('electrical', svgNodes)

      clearInterval(tryRegister)
    }
  }, 50)
})
</script>
```

---

## 底层 API 参考

### sanitizeSvgForX6(rawSvg: string)

将 SVG 字符串清洗为 X6 可用的 JSON markup。

**返回值**：
```ts
{
  markup: any[]           // X6 JSON markup 树
  viewBox: string          // SVG viewBox 字符串
  defs: string            // defs 元素 HTML
  vbWidth: number         // viewBox 宽度
  vbHeight: number        // viewBox 高度
  vbX: number             // viewBox X 偏移
  vbY: number             // viewBox Y 偏移
  hasFill: boolean        // 是否包含填充元素
  hasStroke: boolean      // 是否包含描边元素
  strokeWidth: number     // 最大描边宽度
}
```

内部会自动处理：
- `fill` / `stroke` 属性继承链（设为 `inherit` 跟随 `svg-body`）
- URL 引用修复（`url(#id)` → 动态 ID）
- `defs` 提取
- 文本元素特殊处理（清除继承描边）
- 元素标签过滤（移除 `title`、`desc`、`metadata`）

### registerSvgNode(item: CustomShapeItem, index: number)

注册单个 SVG 为 X6 自定义节点，shape 名称为 `svg-node-{index}`。

### registerSvgNodes(items: CustomShapeItem[], graph: Graph)

批量注册并挂载 defs。

### mountSvgDefs(graph: Graph, defStr: string)

将 SVG defs 挂载到画布顶层 SVG（用于渐变、图案、滤镜等引用）。

### createSvgPreviewNode(graph: Graph, item: CustomShapeItem)

为 Stencil 创建等比缩放的预览节点（限制在 30×30 内，保持原始比例）。

### createLocalImagePreviewNodes(graph: Graph, images: Array<{label: string, dataUrl: string}>)

为 Stencil 创建本地图片预览节点。

---

## 高级用法

### 节点属性动态调整

SVG 节点注册后，可以通过 Stencil 配置覆盖属性：

```ts
const stencilGroups: KoruStencilGroup[] = [
  {
    name: 'electrical',
    label: '电气符号',
    items: [
      {
        // 引用已注册的 SVG 节点
        shape: 'svg-node-0',   // 变压器
        label: '主变压器',
        width: 46,
        height: 46,
        // 覆盖默认 attrs
        attrs: {
          'svg-body': {
            color: '#165DFF',  // 改变 SVG 颜色
            stroke: '#165DFF',
            fill: '#165DFF',
          },
        },
        data: { type: 'transformer' },
      },
    ],
  },
]
```

### 多色 SVG 支持

如果 SVG 包含多色元素（不同的 `fill` 或 `stroke`），注册逻辑会：
- 保留部分元素的原始 `fill`/`stroke`（如 `fill="none"` 的轮廓元素）
- 将可继承的元素设为 `inherit`，跟随 `svg-body` 的 `color` 属性
- 这样可以通过修改 `svg-body` 的 `color` 来整体改变 SVG 颜色

### 运行时动态注册

SVG 节点可以在运行时动态注册：

```ts
const store = useCanvasStore()

function addNewSvg(item: CustomShapeItem) {
  const graph = store.x6GraphRef.value
  if (!graph) return

  const index = store.componentConfig.customShapes.length
  registerSvgNode(item, index)
  store.componentConfig.customShapes.push(item)
}
```

### 持久化注意

SVG 节点注册后创建的实例会被 X6 正常序列化。持久化时会保存：
- `shape: 'svg-node-0'`（shape 标识）
- 节点位置、尺寸、attrs、data 等所有属性

恢复时需要重新注册相同的 SVG 节点（确保 shape 名称和顺序一致），否则会出现 shape 找不到的错误。

---

## 常见问题

### Q: SVG 节点显示为黑色方框怎么办？

可能原因：
1. SVG 没有设置 `viewBox` → 系统会使用 512×512 默认值
2. SVG 使用了不支持的标签 → 检查是否包含 `<title>`、`<desc>` 等不可见标签
3. `fill` 属性未正确处理 → 确保 SVG 的 `fill` 属性有效

### Q: SVG 节点颜色无法动态修改？

确保使用 `svg-body` 选择器修改颜色：

```ts
node.setAttrs({
  'svg-body': {
    color: '#FF0000',  // 控制整体颜色
  },
})
```

因为 SVG 元素的 `fill`/`stroke` 已经设为 `inherit`，会跟随 `svg-body` 的 `color` 属性。

### Q: 如何让 SVG 节点不显示连线桩？

在创建节点时不传 `ports` 配置即可，或者修改 ports 组的 `visibility` 属性。
