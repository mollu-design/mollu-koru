# 快速开始（Quick Start）

## 安装

```bash
# 使用 pnpm（推荐）
pnpm add @mollu/koru @antv/x6@^3.1.7

# 使用 npm
npm install @mollu/koru @antv/x6@^3.1.7
```

### Peer Dependencies

| 依赖                   | 版本要求  | 说明                      |
| ---------------------- | --------- | ------------------------- |
| `vue`                  | `^3.4.0`  | 框架                      |
| `@antv/x6`             | `^3.1.7`  | 底层图编辑引擎            |
| `@arco-design/web-vue` | `^2.58.0` | UI 组件库（插件自动注册） |

> **注意**：`@antv/x6` 是必须的 peer dependency。如果未安装，控制台会输出清晰的错误提示：
> `[Koru-Topology] 缺少依赖：@antv/x6 未安装。请执行：pnpm add @antv/x6@^3.1.7`

---

## 方式一：全局插件注册（推荐）

在 `main.ts` 中注册插件，即可在任何模板中直接使用所有组件，无需手动 import：

```ts
// main.ts
import { createApp } from 'vue'
import { KoruTopologyPlugin } from '@mollu/koru/topology'
import App from './App.vue'

const app = createApp(App)
app.use(KoruTopologyPlugin)
app.mount('#app')
```

插件会自动完成：

- 检查 `@antv/x6` 依赖是否已安装（未安装时输出清晰的安装提示）
- 注册基础节点形状（`custom-rect`、`custom-circle`、`custom-text` 等 7 种内置形状）
- 注册 `@arco-design/web-vue` 组件及图标
- 全局注册 `<KoruGraphEditor>`、`<KoruToolbar>`、`<KoruMinimap>`、`<KoruContextMenu>`、`<KoruPropertyPanel>`
- 注入全局样式（reset / variables / global / anim）

---

## 方式二：按需手动导入

如果不想全局注册，可以按组件手动 import：

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { KoruGraphEditor, KoruToolbar } from '@mollu/koru/topology'
import type { KoruGraphData } from '@mollu/koru/topology'
import '@arco-design/web-vue/dist/arco.css'
import '@mollu/koru/style/koru.css'
</script>
```

---

## 最小示例：编辑模式

```vue
<template>
  <div style="height: 100vh">
    <koru-graph-editor v-model:graph="graphData" mode="edit" @save="handleSave" />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { setComponentConfig, type KoruGraphData } from '@mollu/koru/topology'

// 1. 全局注册组件配置（一次设置、全组件生效）
//    Stencil 分组已内置默认配置（基础图形/电气符号/模板/文件等），无需自定义
//    如需扩展自定义分组，通过 setComponentConfig({ stencilGroups }) 覆盖即可
setComponentConfig({
  toolbarName: '我的拓扑编辑器',
  toolbarLogo: '/logo.png',
  stencilWidth: 210,
})

// 2. 画布数据
const graphData = ref<KoruGraphData>({ nodes: [], edges: [] })

// 3. 保存回调
function handleSave(data: { diagramData: any; bindingRegistry: any[] }) {
  console.log('画布数据:', data.diagramData)
  console.log('绑定注册表:', data.bindingRegistry)
}
</script>
```

### 效果说明

- 左侧：Stencil 面板，拖拽元件到画布
- 中间：X6 画布，支持拖拽、连线、撤销/重做
- 右侧：属性面板，选中节点后编辑属性
- 顶部：工具栏，保存 / 预览 / 缩放 / 全屏

---

## 最小示例：预览模式

```vue
<template>
  <div style="height: 100vh">
    <koru-preview
      v-model:graph="graphData"
      :show-test-tools="true"
      @cell-event="onCellEvent"
      @data-updated="onDataUpdated"
      @action-triggered="onActionTriggered"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { KoruPreview, buildFetchData, dbGet, setBindingConfig } from '@mollu/koru/topology'
import type { BindingRegistryItem } from '@mollu/koru/topology'

const graphData = ref<any>({ nodes: [], edges: [] })

// 从后端或 IndexedDB 加载已保存的画布数据
onMounted(async () => {
  const raw = await dbGet('koru-diagram-data')
  if (raw) {
    const parsed = JSON.parse(raw)
    graphData.value = parsed.cells
      ? { cells: parsed.cells, canvas: parsed.canvas }
      : { nodes: [], edges: [] }
  }

  // 绑定注册表（由保存接口回传）
  // 实际项目中应从保存接口获取，这里简化处理
  const bindingRegistry: BindingRegistryItem[] = []

  // 构建 fetchData 函数
  const fetchData = buildFetchData(bindingRegistry, async () => {
    return await fetch('/api/realtime').then((r) => r.json())
  })

  // 通过全局配置对接实时数据源
  setBindingConfig({
    values: {},
    fetchData,
    pollInterval: 2000, // 2 秒轮询
    setValue: () => {},
    tick: () => {},
    runTest: () => [],
  })
})

// 图元事件回调
function onCellEvent(payload: {
  eventType: string
  cellId: string
  shape: string
  data: Record<string, any>
}) {
  console.log(`[${payload.eventType}]`, payload.cellId)
}

// 数据更新回调
function onDataUpdated(data: Record<string, number | string | null>) {
  console.log('数据更新:', data)
}

// 触发器动作回调
function onActionTriggered(info: { actionType: string; cellId: string; actionValue: any }) {
  console.log(`[action:${info.actionType}]`, info.cellId, info.actionValue)
}
</script>
```

---

## 全局配置速查

在 `main.ts` 或根组件中调用以下函数，即可全局配置所有 Koru 组件的行为：

```ts
import {
  setMultiStateConfig, // 多状态：测点/设备候选列表
  setBindingConfig, // 绑定：实时数据源、写入回调
  setDeviceConfig, // 设备：属性面板设备树
  setComponentConfig, // UI：工具栏、Stencil、Logo
} from '@mollu/koru/topology'

// 多状态配置
setMultiStateConfig({
  pointOptions: [
    { value: 'breaker_state', label: '断路器状态' },
    { value: 'switch_state', label: '刀闸状态' },
  ],
  statePresets: ['合闸', '分闸', '故障', '检修'],
})

// 绑定/测试配置
setBindingConfig({
  values: {},
  setValue: (cellId, device, dataPoint, value) => {
    // 对接实时数据库
  },
  tick: () => {
    // 触发画布刷新
  },
  fetchData: async () => {
    // 返回扁平格式实时数据
    return {}
  },
  pollInterval: 2000,
})

// 设备配置
setDeviceConfig({
  deviceOptions: [
    { value: 'main_transformer', label: '主变压器' },
    { value: 'breaker_1', label: '1#断路器' },
  ],
  deviceCatalog: [
    {
      value: 'main_transformer',
      label: '主变压器',
      points: [
        { value: 'temperature', label: '温度' },
        { value: 'oil_pressure', label: '油压' },
      ],
    },
  ],
})

// UI 组件配置
setComponentConfig({
  toolbarName: '我的编辑器',
  toolbarLogo: '/logo.png',
  stencilWidth: 210,
  showToolbar: true,
  showStencil: true,
  showPropertyPanel: true,
  showMinimap: false,
})
```

> **详细说明**：参见 [global-config.md](./global-config.md)

---

## 数据模型

`KoruGraphData` 是编辑器与预览器之间的统一数据格式：

```ts
interface KoruGraphData {
  nodes: KoruNodeData[] // 节点列表
  edges: KoruEdgeData[] // 连线列表
}

interface KoruNodeData {
  id: string
  shape: string
  x: number
  y: number
  width: number
  height: number
  label?: string
  attrs?: Record<string, any>
  data?: Record<string, any>
  ports?: KoruPortData[]
}

interface KoruEdgeData {
  id: string
  source: string
  target: string
  sourcePort?: string
  targetPort?: string
  label?: string
  attrs?: Record<string, any>
  data?: Record<string, any>
}
```

> 保存时 `@save` 事件会返回 `diagramData: { cells, canvas }`，这是 X6 原生的序列化格式，包含完整的画布配置和图元数据。

---

## 构建 & 开发

### 本地开发

```bash
cd mollu-koru
pnpm install
pnpm dev        # 监听模式，watch 编译
```

### 生产构建

```bash
pnpm build      # 输出 dist/ 目录，包含 ESM / CJS / DTS
```

### 产物结构

```
dist/
├── index.es.js              # 根入口 ESM
├── index.cjs                # 根入口 CJS
├── index.d.ts               # 根入口类型
├── topology/
│   ├── index.es.js          # @mollu/koru/topology ESM
│   ├── index.cjs            # @mollu/koru/topology CJS
│   └── index.d.ts           # 拓扑模块类型
├── plugins/
│   └── flow/
│       └── index.es.js      # @mollu/koru/plugins/flow
└── style/
    ├── koru.css             # 全局样式（自动注入）
    └── topology.css         # 拓扑模块样式
```

---

## 常见问题

### Q: 如何获取画布实例并调用方法？

通过 `ref` 获取组件实例：

```ts
const koruRef = ref<InstanceType<typeof KoruGraphEditor>>()

// 调用实例方法
koruRef.value?.zoomIn()
koruRef.value?.fitView()
koruRef.value?.undo()
koruRef.value?.redo()

// 获取绑定注册表
const registry = koruRef.value?.getBindingRegistry()
```

> **完整实例方法列表**：参见 [component-api.md](./component-api.md) 的「实例方法」章节

### Q: 如何在保存时同时传递绑定注册表给后端？

`@save` 事件已经自动返回了 `bindingRegistry`：

```ts
function handleSave(data: { diagramData: any; bindingRegistry: any[] }) {
  // data.diagramData → 画布完整数据
  // data.bindingRegistry → 绑定注册表，发送给后端建立 WS 订阅
  backend.saveDiagram(data.diagramData, data.bindingRegistry)
}
```

### Q: 如何自定义 SVG 节点？

使用 `registerSvgNodes()` 注册自定义 SVG 形状，参见 [svg-custom-nodes.md](./svg-custom-nodes.md)。

### Q: 数据持久化如何工作？

默认使用 IndexedDB 自动保存/恢复。通过 `persistenceKey` prop 控制：

```vue
<koru-graph-editor persistence-key="my-diagram-key" />
```

> 详细说明：参见 [persistence.md](./persistence.md)
