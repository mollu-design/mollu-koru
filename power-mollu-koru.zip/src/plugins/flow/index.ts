/**
 * @mollu/koru/plugins/flow 流程图插件
 *
 * 提供流程图专用的节点形状、连线类型、布局算法等扩展能力。
 * 仅依赖 core-kernel，不依赖 topology 业务层。
 */

import { KoruEventBus } from '../../core-kernel/event-bus'
import { KoruEvent } from '../../core-kernel/types'
import type { App } from 'vue'

/** 流程图节点形状 */
export const FlowNodeShapes = {
  START: 'flow-start',
  END: 'flow-end',
  PROCESS: 'flow-process',
  DECISION: 'flow-decision',
  SUBPROCESS: 'flow-subprocess',
  DOCUMENT: 'flow-document',
} as const

/** 流程图配置 */
export interface FlowPluginOptions {
  /** 是否启用自动布局 */
  autoLayout?: boolean
  /** 是否启用泳道 */
  swimlane?: boolean
}

/** 流程图插件注册 */
export const FlowPlugin = {
  install(app: App, options?: FlowPluginOptions): void {
    // 注册流程图节点形状
    // 注册流程图连线类型
    // 注册自动布局能力
    console.log('[Koru FlowPlugin] installed', options)
  },
}
