<template>
  <a-modal :visible="visible" title="模板管理" :footer="false" :width="720" @cancel="handleCancel">
    <div class="koru-template-body">
      <div class="koru-template-header">
        <span class="koru-template-count">
          共 {{ displayTemplates.length }} 个模板
          <span v-if="sourceType !== 'local'" class="koru-template-source">
            （{{ sourceType === 'external' ? '外部数据' : '接口数据' }}）
          </span>
        </span>
        <a-space>
          <a-button size="small" :loading="fetching" @click="handleRefresh">刷新</a-button>
          <a-popconfirm v-if="canClear" content="确认清空全部模板?" @ok="clearAllTemplates">
            <a-button
              size="small"
              status="danger"
              :disabled="displayTemplates.length === 0"
            >
              清空全部
            </a-button>
          </a-popconfirm>
        </a-space>
      </div>

      <a-empty v-if="!fetching && displayTemplates.length === 0" :description="emptyText" />

      <div v-else class="koru-template-list">
        <div v-for="(tpl, index) in displayTemplates" :key="tpl.name + '_' + index" class="koru-template-item">
          <div class="koru-template-thumb">
            <a-tooltip v-if="tpl.thumbnail" :content-style="{ maxWidth: '320px' }">
              <template #content>
                <img :src="tpl.thumbnail" alt="" class="koru-template-thumb-zoom" />
              </template>
              <img :src="tpl.thumbnail" alt="" />
            </a-tooltip>
            <span v-else>{{ tpl.name.slice(0, 1) }}</span>
          </div>
          <div class="koru-template-info">
            <a-input
              v-if="editingIndex === index"
              v-model="editingName"
              size="small"
              @press-enter="confirmRename"
              @blur="confirmRename"
            />
            <span v-else class="koru-template-name">{{ tpl.name }}</span>
          </div>
          <div class="koru-template-actions">
            <a-button size="mini" type="primary" @click="applyTemplate(tpl)">应用</a-button>
            <a-button size="mini" :disabled="isReadonly" @click="startRename(index, tpl.name)">
              重命名
            </a-button>
            <a-popconfirm v-if="!isReadonly" content="确认删除该模板?" @ok="deleteTemplate(index)">
              <a-button size="mini" status="danger">删除</a-button>
            </a-popconfirm>
          </div>
        </div>
      </div>
    </div>
  </a-modal>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { dbGet, dbSet } from '../utils/storage'

export interface TemplateItem {
  name: string
  data: any
  thumbnail?: string
}

const props = withDefaults(
  defineProps<{
    visible: boolean
    externalTemplates?: TemplateItem[]
    fetchTemplates?: () => Promise<TemplateItem[]>
    useExternal?: boolean
    editableExternal?: boolean
  }>(),
  {
    externalTemplates: () => [],
    fetchTemplates: undefined,
    useExternal: false,
    editableExternal: false,
  },
)

const emit = defineEmits<{
  (e: 'update:visible', v: boolean): void
  (e: 'apply', tpl: TemplateItem): void
  (e: 'change', templates: TemplateItem[]): void
  /** 模板事件：统一对外分发，组件内部已完成 IndexedDB 操作 */
  (e: 'template', payload: { action: 'save' | 'delete' | 'clear'; template?: TemplateItem; templates?: TemplateItem[] }): void
}>()

const LOCAL_KEY = 'koru-templates'
const localTemplates = ref<TemplateItem[]>([])
const fetching = ref(false)
const editingIndex = ref(-1)
const editingName = ref('')

const sourceType = computed<'local' | 'external' | 'api'>(() => {
  if (props.useExternal && props.externalTemplates && props.externalTemplates.length > 0) {
    return 'external'
  }
  if (props.useExternal && props.fetchTemplates) {
    return 'api'
  }
  return 'local'
})

const displayTemplates = computed<TemplateItem[]>(() => {
  if (sourceType.value === 'local') return localTemplates.value
  return props.externalTemplates || []
})

const isReadonly = computed(() => {
  if (sourceType.value === 'local') return false
  return !props.editableExternal
})

const canClear = computed(() => sourceType.value === 'local')

const emptyText = computed(() => {
  if (fetching.value) return ''
  if (sourceType.value === 'external') return '暂无外部模板数据'
  if (sourceType.value === 'api') return '接口未返回模板数据'
  return '暂无模板，可在保存时「保存为模板」'
})

const loadLocal = async () => {
  try {
    const raw = await dbGet(LOCAL_KEY)
    localTemplates.value = raw ? JSON.parse(raw) : []
  } catch {
    localTemplates.value = []
  }
}

const persistLocal = async () => {
  await dbSet(LOCAL_KEY, JSON.stringify(localTemplates.value))
  emit('change', [...localTemplates.value])
}

const loadFromApi = async () => {
  if (!props.fetchTemplates) return
  fetching.value = true
  try {
    const data = await props.fetchTemplates()
    if (Array.isArray(data)) {
      emit('change', data)
    }
  } catch (e) {
    console.error('加载模板失败', e)
  } finally {
    fetching.value = false
  }
}

const resetEditing = () => {
  editingIndex.value = -1
  editingName.value = ''
}

const handleCancel = () => {
  resetEditing()
  emit('update:visible', false)
}

const handleRefresh = async () => {
  if (sourceType.value === 'api') {
    await loadFromApi()
  } else if (sourceType.value === 'local') {
    await loadLocal()
  }
  resetEditing()
}

const clearAllTemplates = async () => {
  if (isReadonly.value) return
  const all = [...localTemplates.value]
  localTemplates.value = []
  await persistLocal()
  emit('template', { action: 'clear', templates: all })
}

const applyTemplate = (tpl: TemplateItem) => {
  emit('apply', tpl)
}

const startRename = (index: number, name: string) => {
  if (isReadonly.value) return
  editingIndex.value = index
  editingName.value = name
}

const confirmRename = async () => {
  const name = editingName.value.trim()
  const index = editingIndex.value
  if (index < 0 || index >= localTemplates.value.length) {
    resetEditing()
    return
  }
  if (!name) {
    resetEditing()
    return
  }
  if (localTemplates.value.some((t, i) => i !== index && t.name === name)) {
    resetEditing()
    return
  }
  localTemplates.value[index] = { ...localTemplates.value[index], name }
  await persistLocal()
  resetEditing()
}

const deleteTemplate = async (index: number) => {
  if (isReadonly.value) return
  if (index < 0 || index >= localTemplates.value.length) return
  const tpl = localTemplates.value[index]
  localTemplates.value.splice(index, 1)
  await persistLocal()
  emit('template', { action: 'delete', template: tpl })
}

const upsertTemplate = async (tpl: TemplateItem) => {
  const idx = localTemplates.value.findIndex((t) => t.name === tpl.name)
  if (idx >= 0) {
    localTemplates.value[idx] = tpl
  } else {
    localTemplates.value.push(tpl)
  }
  await persistLocal()
}

watch(
  () => props.visible,
  async (val) => {
    if (val) {
      if (sourceType.value === 'api') {
        await loadFromApi()
      } else if (sourceType.value === 'local') {
        await loadLocal()
      }
      resetEditing()
    }
  },
)

defineExpose({ loadLocal, upsertTemplate, localTemplates })
</script>

<style scoped>
.koru-template-body {
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-height: 70vh;
  overflow-y: auto;
}

.koru-template-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.koru-template-count {
  font-size: 13px;
  color: #86909c;
}

.koru-template-source {
  font-size: 12px;
  color: #165dff;
}

.koru-template-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  max-height: 420px;
  overflow-y: auto;
}

.koru-template-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border: 1px solid #e5e6eb;
  border-radius: 6px;
  background: #fff;
}

.koru-template-thumb {
  width: 56px;
  height: 56px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #e5e6eb;
  border-radius: 4px;
  overflow: hidden;
  background: #f7f8fa;
  font-size: 20px;
  color: #4e5969;

  img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}

.koru-template-thumb-zoom {
  max-width: 300px;
  max-height: 300px;
}

.koru-template-info {
  flex: 1;
  min-width: 0;
}

.koru-template-name {
  font-size: 14px;
  color: #1d2129;
  word-break: break-all;
}

.koru-template-actions {
  display: flex;
  gap: 6px;
  flex-shrink: 0;
}
</style>
