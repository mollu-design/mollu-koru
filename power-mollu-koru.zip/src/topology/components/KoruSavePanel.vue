<template>
  <a-modal :visible="visible" title="保存" :footer="false" :width="520" @cancel="handleClose">
    <div class="koru-save-panel">
      <!-- 保存到本地 -->
      <div class="koru-save-section">
        <div class="koru-save-section-title">保存数据</div>
        <p class="koru-save-desc">将当前画布数据保存到本地浏览器存储，刷新页面后可从本地恢复。</p>
        <div class="koru-save-actions">
          <a-button
            type="primary"
            :loading="saving"
            :disabled="!hasCanvasContent"
            @click="handleSave"
          >
            保存设计图
          </a-button>
          <a-button v-if="hasLocalData" :disabled="restoring" @click="handleRestore">
            从本地恢复
          </a-button>
          <a-button v-if="hasLocalData" status="warning" :disabled="clearing" @click="handleClear">
            清空本地数据
          </a-button>
        </div>
      </div>

      <a-divider />

      <!-- 另存为模板 -->
      <div class="koru-save-section">
        <div class="koru-save-section-title">另存为模板</div>
        <p class="koru-save-desc">保存后将在左侧「我的模板」分组中显示，可拖拽到画布使用。</p>
        <div class="koru-save-template-form">
          <a-input
            v-model="templateName"
            placeholder="请输入模板名称"
            :max-length="50"
            show-word-limit
            @keyup.enter="handleSaveAsTemplate"
            size="large"
          />
          <a-button
            type="primary"
            :disabled="!templateName.trim() || !hasCanvasContent"
            @click="handleSaveAsTemplate"
            size="large"
          >
            保存为模板
          </a-button>
        </div>
      </div>

      <!-- 空画布提示 -->
      <a-alert
        v-if="visible && !hasCanvasContent"
        type="warning"
        :show-icon="false"
        class="koru-save-empty-hint"
      >
        <template #title>画布为空，请先添加图元后再保存</template>
      </a-alert>

      <a-alert
        v-if="autoSaveEnabled"
        type="info"
        :show-icon="false"
        class="koru-save-autosave-hint"
      >
        <template #title>
          自动保存已开启，画布变更将在 {{ autoSaveDebounceMs }}ms 后自动保存
        </template>
      </a-alert>
    </div>
  </a-modal>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, type Ref } from 'vue'
import { Message } from '@arco-design/web-vue'
import type { Graph } from '@antv/x6'
import { useCanvasStore } from '../stores/canvasStore'
import { dbGet, dbSet, dbRemove } from '../utils/storage'
import { serializeKoruCanvasConfig, deserializeKoruCanvasConfig } from '../types'
import { applyKoruCanvasConfig } from '../composables/useKoruCanvasConfig'
import { collectBindingRegistry } from '../composables/useBindingRegistry'

const SAVE_KEY = 'koru-diagram-data'

const props = withDefaults(
  defineProps<{
    visible: boolean
    graphRef?: Ref<Graph | null>
    autoSaveEnabled?: boolean
    autoSaveDebounceMs?: number
  }>(),
  {
    autoSaveEnabled: false,
    autoSaveDebounceMs: 1500,
  },
)

const emit = defineEmits<{
  (e: 'update:visible', v: boolean): void
  (e: 'save', data: { diagramData: any; bindingRegistry: any[] }): void
  (e: 'saveTemplate', name: string): void
  (e: 'restore', data: any): void
}>()

const store = useCanvasStore()
const x6GraphRef = store.x6GraphRef
const saving = ref(false)
const restoring = ref(false)
const clearing = ref(false)
const hasLocalData = ref(false)
const templateName = ref('')

function getGraph(): Graph | null {
  return props.graphRef?.value || x6GraphRef?.value || null
}

/** 判断画布是否为空（无任何节点和边） */
function isGraphEmpty(): boolean {
  const graph = getGraph()
  if (!graph) return true
  const cells = graph.getCells?.() || []
  return cells.length === 0
}

/** 画布是否有内容（弹窗打开时快照） */
const hasCanvasContent = ref(false)

/** 刷新画布内容状态 */
function refreshCanvasContent() {
  hasCanvasContent.value = !isGraphEmpty()
}

async function checkLocalData() {
  const raw = await dbGet(SAVE_KEY)
  hasLocalData.value = !!raw
}

const handleClose = () => {
  emit('update:visible', false)
}

const handleSave = async () => {
  const graph = getGraph()
  if (!graph) return
  if (isGraphEmpty()) {
    Message.warning('画布为空，请先添加图元后再保存')
    return
  }
  saving.value = true
  try {
    const diagramData = {
      cells: graph.toJSON().cells || [],
      canvas: serializeKoruCanvasConfig(store.canvasConfig.value!),
    }
    // 采集绑定注册表，供后端接收 / WS 订阅依据
    const bindingRegistry = collectBindingRegistry(graph)
    await dbSet(SAVE_KEY, JSON.stringify(diagramData))
    hasLocalData.value = true
    emit('save', { diagramData, bindingRegistry })
    handleClose()
  } catch (e) {
    console.error('保存失败', e)
  } finally {
    saving.value = false
  }
}

const handleRestore = async () => {
  restoring.value = true
  try {
    const raw = await dbGet(SAVE_KEY)
    if (!raw) return
    const data = JSON.parse(raw)
    const graph = getGraph()
    if (graph) {
      graph.fromJSON({ cells: data.cells || [] })
    }
    // 恢复画布配置
    if (data.canvas) {
      const restored = deserializeKoruCanvasConfig(data.canvas)
      store.canvasConfig.value = { ...restored }
      if (graph) {
        applyKoruCanvasConfig(graph, restored)
      }
    }
    emit('restore', data)
    handleClose()
  } catch (e) {
    console.error('恢复失败', e)
  } finally {
    restoring.value = false
  }
}

const handleClear = async () => {
  clearing.value = true
  try {
    await dbRemove(SAVE_KEY)
    hasLocalData.value = false
    handleClose()
  } catch (e) {
    console.error('清空失败', e)
  } finally {
    clearing.value = false
  }
}

const handleSaveAsTemplate = () => {
  const name = templateName.value.trim()
  if (!name) return
  if (isGraphEmpty()) {
    Message.warning('画布为空，无法保存为模板')
    return
  }
  emit('saveTemplate', name)
  templateName.value = ''
  handleClose()
}

onMounted(() => {
  checkLocalData()
})

watch(
  () => props.visible,
  (v) => {
    if (v) {
      checkLocalData()
      refreshCanvasContent()
    }
  },
)
</script>

<style scoped>
.koru-save-panel {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.koru-save-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px 0;
}

.koru-save-section-title {
  font-size: 15px;
  font-weight: 600;
  color: #1d2129;
}

.koru-save-desc {
  font-size: 13px;
  color: #86909c;
  margin: 0;
  line-height: 1.5;
}

.koru-save-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.koru-save-template-form {
  display: flex;
  gap: 8px;
  align-items: flex-start;
}

.koru-save-empty-hint {
  margin-top: 8px;
}

.koru-save-autosave-hint {
  margin-top: 8px;
}
</style>
